package com.student;
import jakarta.persistence.*;

@Entity
@Table(name = "student")
 
//POJO class
public class StudentData {
 
    @Id 
    @Column(name = "studentId")
    private int id;
 
    @Column(name = "studentfirstName")
    private String firstName;
 
    @Column(name = "studentlastName")
    private String lastName;
    
    @Column(name = "age") 
    private int age;
 

    @Column(name = "address") 
    private String address;
     
    @Column(name = "course") 
    private String course;
    
    public int getId()
    { 
    	return id; 
    }
 
    public void setId(int id)
    { 
    	this.id = id;
    }
 
    public String getStudentfirstName() 
    {
    	return firstName; 
    }
 
    public void setStudentfirstName(String firstName)
    {
        this.firstName = firstName;
    }
 
    public String getStudentlastname() 
    { 
    	return lastName;
    }
 
    public void setStudentlastname(String lastName)
    {
        this.lastName = lastName;
    }
    public int getAge()
    { 
    	return age; 
    }
 
    public void setAge(int age)
    { 
    	this.age = age;
    }
    public String getAddress()
    {
    	return address; 
    }
 
    public void setAddress(String address)
    {
        this.address = address;
    }
    public String getCourse() 
    {
    	return course; 
    }
 
    public void setCourse(String course)
    {
        this.course = course;
    }
}

