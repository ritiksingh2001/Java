package com.student;

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;

	import com.student.StudentData;

     public class app {
        public static void main(String[] args) 
	{ 
        // Create Configuration
	   Configuration configuration = new Configuration();
	  configuration.configure("hibernate.cfg.xml");
      configuration.addAnnotatedClass(StudentData.class);
		 
	 // Create Session Factory
  SessionFactory sessionFactory = configuration.buildSessionFactory();
		 
      // Initialize Session Object
      Session session =  sessionFactory.openSession();
		 
		StudentData st1 = new StudentData();
		StudentData st2 = new StudentData();
		StudentData st3=new StudentData();
		StudentData st4= new StudentData();
		 
     st1.setId(1);
	 st1.setStudentfirstName("Aditya");
	 st1.setStudentlastname("Kumar");
     st1.setAddress("69/type3,muradnagar");
     st1.setAge(21);
     st1.setCourse("Btech");
     
     st2.setId(2);
     st2.setStudentfirstName("Ganja");
     st2.setStudentlastname("yadav");
     st2.setAddress("4/ak murti");
     st2.setAge(23);
     st2.setCourse("Btech");
     
     st3.setId(3);
     st3.setStudentfirstName("Pilot");
     st3.setStudentlastname("raj");
     st3.setAddress("noida sec 62");
     st3.setAge(23);
     st3.setCourse("Btech");
     
     st4.setId(4);
     st4.setStudentfirstName("Bacchi");
     st4.setStudentlastname("tyagi");
     st4.setAddress("indrapuram");
     st4.setAge(23);
     st4.setCourse("Btech");
		 
	session.beginTransaction();
		 
	 // Here we have used
    // save() method of JPA
    session.save(st1);
    session.save(st2);
    session.save(st3);
    session.save(st4);
		 
    session.getTransaction().commit();
				
			}
}


