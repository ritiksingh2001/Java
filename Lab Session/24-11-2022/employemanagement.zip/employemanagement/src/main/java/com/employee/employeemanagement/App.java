package com.employee.employeemanagement;

import com.dao.EmployeeDao;
import com.dao.EmployeeDetailDao;
import com.entity.Employee;
import com.entity.EmployeeDetail;

// kindly uncomment line for execution purpose only.........

public class App {
	public static void main(String[] args) {
		// Save two employee
		Employee employee = new Employee("adii", "kumar", 21);
		EmployeeDetail employeeDetail = new EmployeeDetail("meerut", "adii02@gmail.com", 165000);
		employee.setEmployeeFirstName("ganja");
		employeeDetail.setEmployee(employee);
		employee.setEmployeeDetail(employeeDetail);

		Employee employee1 = new Employee("luv", "thakur", 26);
		EmployeeDetail employeeDetail1 = new EmployeeDetail("meerut", "luv02@gmail.com", 165000);
		 employee1.setEmployeeFirstName("pilot");
		employeeDetail1.setEmployee(employee1);
		employee1.setEmployeeDetail(employeeDetail1);

		EmployeeDao emplo = new EmployeeDao();

		// for save data
		emplo.saveEmployee(employee);
		 emplo.saveEmployee(employee1);
		Employee e1 = emplo.getEmployee(1);

		System.out.println(e1.getEmployeeFirstName());
		 e1.setEmployeeFirstName("bhura");
		emplo.deleteEmployee(1);

		EmployeeDetailDao emp = new EmployeeDetailDao();
		emp.incrementEmployeeSalary(1, 30);
		emp.deleteEmployeeDetail(1);

	}
}

